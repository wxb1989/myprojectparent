package com.zhh.hessian;

public class HessianRequestContext {

}
