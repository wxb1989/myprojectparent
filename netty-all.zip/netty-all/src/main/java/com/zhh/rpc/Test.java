package com.zhh.rpc;

public class Test {

	public Test(){
		
	}
	
	public int add(Integer a,Integer b){
		return a+b;
	}
	
	public static void main(String[] args){
		
		System.out.println(Integer.MAX_VALUE - 3);
	}
}
